import TreeSelectSn from './index.vue';

export default TreeSelectSn;
